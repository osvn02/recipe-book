#include <iostream>
#include "menu.h"

using namespace std;

int main()
{
    Menu myMenu;
    myMenu.start();
}
